//
//  helperModel.swift
//  fetchDataFromAPIusingInitMethod
//
//  Created by iMac on 15/09/22.
//

import Foundation
import UIKit


class nasaData{
    var date: String?
    var explanation: String?
    var hdUrlImage: String?
    var mediaType: String?
    var serviceVersion: String?
    var title: String?
    var urlImage: String?
    var copyRight: String?
    
    init(dic: [String: Any]) {
        if let date = dic["date"] as? String {
            self.date = date
        }
        if let explanation = dic["explanation"] as? String {
            self.explanation = explanation
        }
        if let hdUrlImage = dic["hdurl"] as? String {
            self.hdUrlImage = hdUrlImage
        }
        if let mediaType = dic["media_type"] as? String {
            self.mediaType = mediaType
        }
        if let serviceVersion = dic["service_version"] as? String {
            self.serviceVersion = serviceVersion
        }
        if let title = dic["title"] as? String {
            self.title = title
        }
        if let copyRight = dic["copyright"] as? String {
            self.copyRight = copyRight
        }
        if let urlImage = dic["url"] as? String {
            self.urlImage = urlImage
        }
    }
}
