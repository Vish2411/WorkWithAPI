//
//  ViewController.swift
//  fetchDataFromAPIusingInitMethod
//
//  Created by iMac on 15/09/22.
//

import UIKit

class ViewController: UIViewController {

    var nasaDatas = [nasaData]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        downloadJSON {
            print("Hello")
        }
    }


    // Fetch Data Using URLSession
    func downloadJSON(compeleted: @escaping ()->()){
        let url = URL(string: "https://api.nasa.gov/planetary/apod?api_key=hkIXPr7NzqnLXOaXe6SbUrB2Qdo2GkxyUX45HDHG")
        
        URLSession.shared.dataTask(with: url!) { serverData, response, Error in
            if Error != nil{
                print(Error?.localizedDescription ?? "")
            }else{
                
                if let data = serverData, let json = self.nsdataToJSON(data: data) as? [String: Any]{
                    let model = nasaData(dic: json)
                    print(model)
                    print(model.title)
                    
                    """
                        if let data = serverData, let json = self.nsdataToJSON(data: data) as? [[String: Any]]{

                            for i in json {
                                let model = nasaData(dic: i)
                                self.nasaDatas.append(model)
                            }
                        }
                    """
                        DispatchQueue.main.async {
                            compeleted()
                        }
                        
                }else{
                    print("Data is NOt Yet")
                }
                
                
            }
        }.resume()
    }
    
}

extension ViewController {
    // Convert from NSData to json object
    func nsdataToJSON(data: Data) -> AnyObject? {
        do {
            return try JSONSerialization.jsonObject(with: data as Data, options: .mutableContainers) as AnyObject
        } catch let myJSONError {
            print(myJSONError)
        }
        return nil
    }
}

    
